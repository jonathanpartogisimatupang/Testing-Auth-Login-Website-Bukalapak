<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Form harus diisi dulu ya</name>
   <tag></tag>
   <elementGuidId>6a49066c-f98c-4d55-925b-cd2ab2796351</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.bl-text.bl-text--caption.bl-text--error</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = '
        Form harus diisi dulu ya
      ' or . = '
        Form harus diisi dulu ya
      ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>1241c74d-b865-4f24-9052-3a1e160a1402</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text bl-text--caption bl-text--error</value>
      <webElementGuid>53eb0f1d-705f-4a8e-a54e-7f907779305c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Form harus diisi dulu ya
      </value>
      <webElementGuid>8c6745f1-08ff-4467-a54f-b2822609d68c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;position__relative&quot;]/div[@class=&quot;container-flf&quot;]/div[@class=&quot;wrapper-input-identity&quot;]/div[@class=&quot;bl-text-field transition__basic is-error&quot;]/div[2]/div[@class=&quot;bl-text-field__message&quot;]/p[@class=&quot;bl-text bl-text--caption bl-text--error&quot;]</value>
      <webElementGuid>e997d570-9c34-49a1-9d5a-9a2eb15fda82</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::p[1]</value>
      <webElementGuid>fbd5ae86-49c9-4b1c-a695-ccaa142e8e60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/preceding::p[1]</value>
      <webElementGuid>56b442c6-293c-4dd9-a7c5-9407d65c3081</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Facebook'])[1]/preceding::p[2]</value>
      <webElementGuid>ee4c0703-dbf2-4631-ba70-8e24e0298298</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Form harus diisi dulu ya']/parent::*</value>
      <webElementGuid>c2655e22-b13b-4900-93ed-11494f648c5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div/p</value>
      <webElementGuid>6792dc4a-ad8a-4bba-ab8a-0a8bc71e3f11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
        Form harus diisi dulu ya
      ' or . = '
        Form harus diisi dulu ya
      ')]</value>
      <webElementGuid>a2e97973-f9e8-41b0-8290-e2f57ef2afad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
