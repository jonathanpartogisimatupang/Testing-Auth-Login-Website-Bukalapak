<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Password yang kamu masukkan salah. Silakan coba lagi</name>
   <tag></tag>
   <elementGuidId>4ad27090-ead8-4013-b542-99a5ae2daada</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.bl-text.bl-text--caption.bl-text--error</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='password'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = '
        Password yang kamu masukkan salah. Silakan coba lagi.
      ' or . = '
        Password yang kamu masukkan salah. Silakan coba lagi.
      ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>c305da15-a737-4a98-a96b-0ccc9c97ffd1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text bl-text--caption bl-text--error</value>
      <webElementGuid>3d602e4b-4c12-40b3-b7a7-ef02d7914748</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Password yang kamu masukkan salah. Silakan coba lagi.
      </value>
      <webElementGuid>8c9b3fd3-70e7-43f7-8e33-beaa57b7af3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;container-ipl z-index__front&quot;]/div[@class=&quot;wrapper-form-ipl&quot;]/div[@class=&quot;mb-20 transition__basic transform__right transform__normal&quot;]/div[@class=&quot;bl-text-field has-value is-error&quot;]/div[2]/div[@class=&quot;bl-text-field__message&quot;]/p[@class=&quot;bl-text bl-text--caption bl-text--error&quot;]</value>
      <webElementGuid>63558690-aadb-442c-b53b-753e89cef3ba</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='password'])[1]/following::p[1]</value>
      <webElementGuid>daf76774-0aba-4dcd-84c2-cd954583c3a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/following::p[5]</value>
      <webElementGuid>526d1017-8b81-4930-9e3a-f72656b6dfa8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lupa Password?'])[1]/preceding::p[1]</value>
      <webElementGuid>a7b2662f-b353-4bcf-baca-fadc4b2e0738</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::p[2]</value>
      <webElementGuid>4d2afd53-8e9b-4732-9287-a36e48bfb1a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Password yang kamu masukkan salah. Silakan coba lagi.']/parent::*</value>
      <webElementGuid>97685415-9b97-4e07-9862-4864b079178e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/p</value>
      <webElementGuid>f227ca27-139a-4f95-9452-058fe2d36916</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
        Password yang kamu masukkan salah. Silakan coba lagi.
      ' or . = '
        Password yang kamu masukkan salah. Silakan coba lagi.
      ')]</value>
      <webElementGuid>6c9d5007-b95c-459f-aba7-cebf9be37618</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
