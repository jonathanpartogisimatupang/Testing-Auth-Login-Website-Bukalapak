<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_User tidak ditemukan</name>
   <tag></tag>
   <elementGuidId>90020c0a-260b-4376-9ec2-c482d3286717</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p.bl-text.bl-text--caption.bl-text--error</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//p[(text() = '
        User tidak ditemukan
      ' or . = '
        User tidak ditemukan
      ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>a53a95e9-afcb-4d33-827f-c458bb276d85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bl-text bl-text--caption bl-text--error</value>
      <webElementGuid>46e84ea0-b2b1-42b1-bd58-53e1af53b26f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        User tidak ditemukan
      </value>
      <webElementGuid>c9ce0c2e-0edc-47f9-8f1c-b174685eb834</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[1]/main[@class=&quot;plf__wrapper&quot;]/div[@class=&quot;plf__container&quot;]/div[@class=&quot;plf__bl-card bl-card has-elevation-1 bl-card--outlined&quot;]/section[1]/section[@class=&quot;position__relative&quot;]/div[@class=&quot;container-flf&quot;]/div[@class=&quot;wrapper-input-identity&quot;]/div[@class=&quot;bl-text-field transition__basic has-value is-error&quot;]/div[2]/div[@class=&quot;bl-text-field__message&quot;]/p[@class=&quot;bl-text bl-text--caption bl-text--error&quot;]</value>
      <webElementGuid>0443509e-39f3-47a3-8736-e8db354885c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Nomor handphone atau email'])[1]/following::p[1]</value>
      <webElementGuid>10240be9-0ca8-459c-af4f-3fd22e1cfc34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lanjut'])[1]/preceding::p[1]</value>
      <webElementGuid>3975d7bd-5c82-46c9-a281-09f68e3dbd92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Facebook'])[1]/preceding::p[2]</value>
      <webElementGuid>38f19330-ea34-48b6-8dd0-8b365e13f9d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='User tidak ditemukan']/parent::*</value>
      <webElementGuid>5232d3b3-a11c-4b5d-b934-c87dcb3722ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div/p</value>
      <webElementGuid>ea6f9242-0796-4707-9237-22871c6fca38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
        User tidak ditemukan
      ' or . = '
        User tidak ditemukan
      ')]</value>
      <webElementGuid>9064deb7-c4d1-425d-bcdc-91d2c9404c78</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
